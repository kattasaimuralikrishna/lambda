import json
import boto3

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('murali')

def lambda_handler(event, context):
    movies=event['movies']
    response = table.get_item(
    Key={
        'movies': movies
    }
    )
    return response
